<?php namespace Vinelab\Rss\Exceptions;

class InvalidFeedFormatException extends RssException {}