<?php namespace Vinelab\Rss\Exceptions;

use RuntimeException;

class RssException extends RuntimeException {}