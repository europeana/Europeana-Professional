<?php namespace Vinelab\Rss\Contracts;

interface ParserInterface {

    public function parse($feed);
}