<?php namespace Vinelab\Rss;

use Illuminate\Support\Collection;

class ArticlesCollection extends Collection {}