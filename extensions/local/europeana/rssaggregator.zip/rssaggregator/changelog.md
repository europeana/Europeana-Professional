# Changelog for RSS Aggregator

* 2.0.0 (2014-08-17)

 * Initial release for Bolt 2.0.0
