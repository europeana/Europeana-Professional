<?php

use Bolt\Extension\Bolt\RSSAggregator\Extension;

$app['extensions']->register(new Extension($app));
